#!/usr/bin/env Rscript

# Convert the exact access-controlled Figure 1 plotting object into a public,
# grid-aggregated object without pregnancy IDs, cluster IDs, or exact DHS
# cluster coordinates.

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages("data.table")

input_file <- file.path(
  repo_root(), "data-restricted", "Figure1_plot_data_exact.RData"
)
if (!file.exists(input_file)) stop("Missing exact Figure 1 data: ", input_file)
load(input_file)

d <- data.table::as.data.table(figure1_temperature_data)
d[, `:=`(
  longitude_grid = round(longitude * 2) / 2,
  latitude_grid = round(latitude * 2) / 2
)]

value_columns <- c(
  "ERA5_derived_C", "factual_C", "counterfactual_C",
  "anthropogenic_warming_C", "panel_a_colour_category",
  "panel_b_colour_category", "panel_c_colour_category",
  "panel_d_colour_category"
)
figure1_temperature_data <- d[, c(
  list(
    longitude = longitude_grid[[1L]],
    latitude = latitude_grid[[1L]],
    source_records = .N
  ),
  lapply(.SD, mean, na.rm = TRUE)
), by = .(longitude_grid, latitude_grid), .SDcols = value_columns]
figure1_temperature_data[, c("longitude_grid", "latitude_grid") := NULL]
figure1_temperature_data <- as.data.frame(figure1_temperature_data)

output_file <- file.path(repo_root(), "data", "Figure1_plot_data.RData")
save(
  figure1_temperature_data, figure1_panel_spec,
  figure1_common_breaks, figure1_difference_breaks,
  file = output_file, compress = "xz", version = 3
)
message("Created public grid-aggregated Figure 1 data: ", output_file)
