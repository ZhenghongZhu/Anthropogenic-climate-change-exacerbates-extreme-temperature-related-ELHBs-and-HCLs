repo_root <- function() {
  configured <- c(
    getOption("earlylife.repro_root", ""),
    Sys.getenv("EARLYLIFE_REPRO_ROOT", unset = "")
  )

  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  script_root <- if (length(file_arg)) {
    dirname(dirname(normalizePath(
      sub("^--file=", "", file_arg[[1L]]), winslash = "/"
    )))
  } else {
    ""
  }

  candidates <- unique(c(configured, script_root, getwd(), dirname(getwd())))
  candidates <- candidates[nzchar(candidates)]
  valid <- vapply(candidates, function(path) {
    file.exists(file.path(path, "R", "00_common.R")) &&
      dir.exists(file.path(path, "data"))
  }, logical(1))

  if (!any(valid)) {
    stop(
      "Cannot locate the repository root. Open early-life-reproducibility.Rproj ",
      "in RStudio, or set options(earlylife.repro_root = 'path/to/repository')."
    )
  }
  normalizePath(candidates[which(valid)[[1L]]], winslash = "/", mustWork = TRUE)
}

load_figure_data <- function(file_name, envir = parent.frame()) {
  path <- file.path(repo_root(), "data", file_name)
  if (!file.exists(path)) stop("Missing data file: ", path)
  load(path, envir = envir)
}

figure_output <- function(file_name) {
  output_dir <- file.path(repo_root(), "outputs", "reproduced")
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  file.path(output_dir, file_name)
}

require_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop("Install required R packages: ", paste(missing, collapse = ", "))
  }
}

save_png <- function(plot, file_name, width, height, dpi = 300) {
  ggplot2::ggsave(
    filename = figure_output(file_name), plot = plot,
    width = width, height = height, units = "in", dpi = dpi,
    bg = "white"
  )
}
