require_packages(c("ggplot2", "sf", "rnaturalearth", "countrycode", "patchwork"))

map_palette <- c("#FFFFFF", "#F8D9D1", "#F6A59A", "#EF685F", "#CD3340", "#8A1025")
map_context_fill <- "#F5F5F4"
map_context_border <- "#B8B8B8"
map_study_border <- "#303030"

country_iso3 <- function(country) {
  countrycode::countrycode(
    country, origin = "country.name", destination = "iso3c",
    custom_match = c("Congo DR" = "COD", "Kyrgyz Republic" = "KGZ")
  )
}

prepare_world_geometry <- function(source_data) {
  world <- rnaturalearth::ne_countries(scale = 50, returnclass = "sf")
  world <- sf::st_make_valid(world)
  source_data$iso3 <- country_iso3(source_data$Country)
  if (anyNA(source_data$iso3)) {
    stop("ISO3 conversion failed: ", paste(source_data$Country[is.na(source_data$iso3)], collapse = ", "))
  }
  study_iso <- unique(source_data$iso3)
  if (!all(study_iso %in% world$iso_a3)) {
    stop("World geometry missing study ISO3 codes: ", paste(setdiff(study_iso, world$iso_a3), collapse = ", "))
  }
  list(world = world, data = source_data)
}

assign_loss_bins <- function(values, breaks, labels) {
  nonzero_labels <- labels[-1L]
  result <- as.character(cut(
    values, breaks = breaks, labels = nonzero_labels,
    include.lowest = TRUE, right = FALSE
  ))
  result[is.finite(values) & values == 0] <- labels[[1L]]
  factor(result, levels = labels)
}

make_map_panel <- function(
  source_data, world, exposure, group_column, group_value,
  breaks, labels, title = NULL, row_label = NULL
) {
  dat <- source_data[
    source_data$exposure == exposure & source_data[[group_column]] == group_value,
  ]
  if (nrow(dat) != 54L) stop("Expected 54 country rows for ", exposure, " / ", group_value)
  dat$bin <- assign_loss_bins(dat$map_value, breaks, labels)
  geom <- world[match(dat$iso3, world$iso_a3), ]
  geom$bin <- dat$bin

  ggplot2::ggplot() +
    ggplot2::geom_sf(
      data = world, fill = map_context_fill, colour = map_context_border,
      linewidth = 0.08
    ) +
    ggplot2::geom_sf(
      data = geom, ggplot2::aes(fill = bin), colour = map_study_border,
      linewidth = 0.16
    ) +
    ggplot2::scale_fill_manual(
      values = stats::setNames(map_palette, labels), limits = labels,
      drop = FALSE, guide = "none", na.value = "#D7D7D7"
    ) +
    ggplot2::coord_sf(xlim = c(-105, 155), ylim = c(-45, 60), expand = FALSE, datum = NA) +
    ggplot2::labs(title = title, y = row_label) +
    ggplot2::theme_void(base_family = "serif") +
    ggplot2::theme(
      plot.title = ggplot2::element_text(
        family = "serif", face = "bold", size = 12.5, hjust = 0,
        margin = ggplot2::margin(0, 0, 5, 0)
      ),
      axis.title.y = ggplot2::element_text(
        family = "serif", face = "bold", size = 11.5,
        angle = 90, margin = ggplot2::margin(0, 3, 0, 0)
      ),
      panel.border = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.42),
      plot.margin = ggplot2::margin(0, 0, 0, 0)
    )
}

make_bottom_legend <- function(title, labels) {
  label_text <- gsub(" to ", "\nto ", labels, fixed = TRUE)
  d <- data.frame(
    x = seq_along(labels), y = 1,
    label = label_text, colour = map_palette
  )
  ggplot2::ggplot(d, ggplot2::aes(x = x, y = y)) +
    ggplot2::geom_point(
      ggplot2::aes(fill = colour), shape = 22, size = 4.0,
      stroke = 0.45, colour = "black"
    ) +
    ggplot2::geom_text(
      ggplot2::aes(y = 0.42, label = label), family = "serif",
      size = 3.1, lineheight = 0.80
    ) +
    ggplot2::annotate(
      "text", x = mean(d$x), y = 1.62, label = title,
      family = "serif", fontface = "bold", size = 4.2
    ) +
    ggplot2::scale_fill_identity() +
    ggplot2::scale_x_continuous(limits = c(0.5, length(labels) + 0.5), expand = c(0, 0)) +
    ggplot2::scale_y_continuous(limits = c(-0.05, 1.85), expand = c(0, 0)) +
    ggplot2::theme_void(base_family = "serif") +
    ggplot2::theme(plot.margin = ggplot2::margin(5, 0, 0, 0))
}

