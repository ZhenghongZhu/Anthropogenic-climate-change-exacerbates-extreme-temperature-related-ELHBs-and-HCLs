#!/usr/bin/env Rscript

# Builds the minimum individual-level analytic object needed to refit Figure 2.
# The resulting RData is derived from DHS microdata and must not be committed to
# a public repository. It is excluded by the repository .gitignore.

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages("data.table")

args <- commandArgs(trailingOnly = TRUE)
input_csv <- if (length(args)) {
  args[[1L]]
} else {
  getOption(
    "earlylife.dhs_analytic_csv",
    Sys.getenv("DHS_ANALYTIC_CSV", unset = "")
  )
}
if (!nzchar(input_csv) || !file.exists(input_csv)) {
  stop(
    "Provide the access-controlled DHS analytic CSV as the first argument, ",
    "set DHS_ANALYTIC_CSV, or set ",
    "options(earlylife.dhs_analytic_csv = 'path/to/file.csv') in RStudio."
  )
}

source_columns <- c(
  "gj", "pid", "DHSID", "weight", "length", "outcome", "tem", "rh",
  "region", "age", "urban", "edu", "wealth", "bmi", "twin", "sex",
  "parity", "month", "temth"
)
header <- names(data.table::fread(input_csv, nrows = 0L))
missing <- setdiff(source_columns, header)
if (length(missing)) stop("Missing source columns: ", paste(missing, collapse = ", "))

raw <- data.table::fread(input_csv, select = source_columns, showProgress = TRUE)
raw[, outcome := data.table::fcase(
  outcome %in% c("preterm birth", "term low birth weight"),
  "small vulnerable newborn",
  default = outcome
)]
raw[, region := data.table::fcase(
  region %in% c("Central Asia", "Eastern Europe"), "Central Asia&Europe",
  region %in% c("Coastal West Africa", "Sahel"), "West Africa",
  default = region
)]
model_data <- raw[, .(
  pregnancy_id = seq_len(.N),
  cluster_id = as.integer(factor(DHSID)),
  country = factor(gj),
  region = factor(region),
  survey_weight = as.numeric(weight),
  gestational_month = as.numeric(length),
  outcome = factor(outcome),
  gestational_temperature = as.numeric(tem),
  relative_humidity = as.numeric(rh),
  maternal_age = as.numeric(age),
  residence = factor(urban),
  maternal_education = factor(edu),
  household_wealth = factor(wealth),
  maternal_bmi = factor(bmi),
  plurality = factor(twin),
  infant_sex = factor(sex),
  parity = factor(parity),
  conception_month = as.numeric(month),
  exposure_class = factor(
    as.character(temth),
    levels = c("1", "2", "3", "4", "5", "6", "7", "8", "9", "99")
  )
)]

model_input_dictionary <- data.frame(
  variable = names(model_data),
  description = c(
    "Sequential pregnancy record identifier",
    "Pseudonymized DHS cluster identifier",
    "DHS country code",
    "Eight-region analysis stratum",
    "DHS survey weight retained from the analytic dataset",
    "Gestational duration in months",
    "Pregnancy outcome; preterm birth and term low birth weight are combined as small vulnerable newborn",
    "Mean gestational temperature in degrees Celsius",
    "Mean gestational relative humidity",
    "Maternal age in years",
    "Urban/rural residence",
    "Maternal education category",
    "Household wealth category",
    "Maternal BMI category",
    "Singleton/plural pregnancy category",
    "Infant sex category",
    "Parity category",
    "Month of conception",
    "Country-specific temperature percentile category; 99 is the 50th-60th percentile reference"
  )
)
model_input_counts <- list(
  pregnancies = nrow(model_data),
  by_region = as.data.frame(table(model_data$region, useNA = "ifany")),
  by_outcome = as.data.frame(table(model_data$outcome, useNA = "ifany"))
)

output_file <- file.path(repo_root(), "data-restricted", "Figure2_model_input.RData")
save(
  model_data, model_input_dictionary, model_input_counts,
  file = output_file, compress = "xz", version = 3
)
message("Created access-controlled model input: ", output_file)
