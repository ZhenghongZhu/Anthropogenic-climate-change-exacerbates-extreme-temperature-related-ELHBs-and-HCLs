#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
source(file.path(repo_root(), "R", "04_map_helpers.R"))
load_figure_data("Figure5_plot_data.RData")

prepared <- prepare_world_geometry(figure5_cost_data)
d <- prepared$data
world <- prepared$world

specs <- list(
  absolute = list(
    title = "(a) ACC-attributable absolute economic cost",
    legend = "2015 US dollars, billions",
    breaks = figure5_scale_spec$absolute,
    labels = c("0.0", ">0.0 to 0.3", "0.3 to 0.7", "0.7 to 1.1", "1.1 to 4.1", ">=4.1")
  ),
  relative = list(
    title = "(b) ACC-attributable relative economic cost",
    legend = "% of 2015 GDP",
    breaks = figure5_scale_spec$relative,
    labels = c("0.0", ">0.0 to 2.5", "2.5 to 4.0", "4.0 to 6.5", "6.5 to 8.7", ">=8.7")
  )
)

make_column <- function(metric, show_rows = FALSE) {
  s <- specs[[metric]]
  exposures <- c("heat", "cold", "net")
  row_labels <- c("Heat", "Cold", "Total loss")
  maps <- lapply(seq_along(exposures), function(i) {
    make_map_panel(
      d, world, exposures[[i]], "metric", metric,
      s$breaks, s$labels,
      title = if (i == 1L) s$title else NULL,
      row_label = if (show_rows) row_labels[[i]] else NULL
    )
  })
  maps[[1L]] / maps[[2L]] / maps[[3L]] / make_bottom_legend(s$legend, s$labels) +
    patchwork::plot_layout(heights = c(1, 1, 1, 0.50))
}

figure5 <- make_column("absolute", TRUE) | make_column("relative", FALSE)
save_png(figure5, "Figure5.png", width = 12.2, height = 6.7, dpi = 300)
