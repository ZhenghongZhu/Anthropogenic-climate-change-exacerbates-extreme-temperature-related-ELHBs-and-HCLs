#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("ggplot2", "patchwork"))
load_figure_data("Figure3_plot_data.RData")

regions <- figure3_plot_spec$regions
region_labels <- c(
  "Central Asia&Europe" = "Central Asia\n& Europe",
  "East Africa" = "East Africa",
  "Latin America" = "Latin America",
  "South Asia" = "South Asia",
  "Southeast Asia" = "Southeast Asia",
  "Southern Africa" = "Southern Africa",
  "West Africa" = "West Africa",
  "West Asia&North Africa" = "West Asia\n& North Africa",
  "Total" = "Total"
)
outcome_colours <- c(
  "Miscarriage" = "#440154", "Stillbirth" = "#B13F2F", "SVN" = "#FFD43B"
)

figure3_outcome_rates$region_factor <- factor(
  figure3_outcome_rates$region, levels = rev(regions),
  labels = rev(unname(region_labels[regions]))
)
figure3_outcome_rates$outcome <- factor(
  figure3_outcome_rates$outcome, levels = c("SVN", "Stillbirth", "Miscarriage")
)

panel_a <- ggplot2::ggplot(
  figure3_outcome_rates,
  ggplot2::aes(x = rate_per_1000, y = region_factor, fill = outcome)
) +
  ggplot2::geom_col(width = 0.64) +
  ggplot2::scale_fill_manual(values = outcome_colours, breaks = c("Miscarriage", "Stillbirth", "SVN")) +
  ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.04))) +
  ggplot2::labs(title = "(a) Outcome rate", x = "Cases per 1,000 pregnancies", y = NULL) +
  ggplot2::theme_classic(base_family = "serif", base_size = 12) +
  ggplot2::theme(
    plot.title = ggplot2::element_text(face = "bold", size = 10.5, hjust = 0),
    axis.text = ggplot2::element_text(size = 11),
    axis.title.x = ggplot2::element_text(size = 12),
    legend.position = "bottom",
    legend.title = ggplot2::element_blank(),
    panel.grid = ggplot2::element_blank()
  )

make_burden_panel <- function(outcome, tag) {
  d <- figure3_scenario_cases[figure3_scenario_cases$panel == outcome, ]
  d$region_factor <- factor(d$region, levels = rev(regions))
  d$scenario_label <- ifelse(
    d$scenario == "Factual" & d$exposure == "cold", "Factual scenario: cold",
    ifelse(
      d$scenario == "Factual" & d$exposure == "heat", "Factual scenario: heat",
      "Counterfactual scenario"
    )
  )
  d$scenario_label <- factor(
    d$scenario_label,
    levels = c("Factual scenario: cold", "Counterfactual scenario", "Factual scenario: heat")
  )

  labels <- unique(d[c("region", "exposure", "ap_label", "ap_signed_percent")])
  labels$region_factor <- factor(labels$region, levels = rev(regions))
  labels$x <- ifelse(labels$exposure == "cold", -7.1, 7.1)
  labels$hjust <- ifelse(labels$exposure == "cold", 0, 1)

  ggplot2::ggplot(d, ggplot2::aes(x = signed_plot_value, y = region_factor)) +
    ggplot2::geom_col(
      ggplot2::aes(fill = scenario_label),
      width = 0.64, position = ggplot2::position_dodge(width = 0.38)
    ) +
    ggplot2::geom_vline(xintercept = 0, colour = "black", linewidth = 0.75) +
    ggplot2::geom_text(
      data = labels,
      ggplot2::aes(x = x, y = region_factor, label = ap_label, hjust = hjust),
      inherit.aes = FALSE, family = "serif", size = 3.8
    ) +
    ggplot2::scale_fill_manual(values = c(
      "Factual scenario: cold" = "#4A88B4",
      "Counterfactual scenario" = "#C6C6C6",
      "Factual scenario: heat" = "#D35C61"
    )) +
    ggplot2::scale_x_continuous(
      limits = c(-7.4, 7.4), breaks = c(-6, -3, 0, 3, 6),
      labels = c(expression(10^6), expression(10^3), "0", expression(10^3), expression(10^6))
    ) +
    ggplot2::labs(title = paste0("(", tag, ") ", outcome), x = NULL, y = NULL) +
    ggplot2::theme_classic(base_family = "serif", base_size = 12) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 12.5, hjust = 0),
      axis.text.y = ggplot2::element_blank(),
      axis.ticks.y = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(size = 10),
      legend.position = "bottom",
      legend.title = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank()
    )
}

panels_bcd <- list(
  make_burden_panel("Miscarriage", "b"),
  make_burden_panel("Stillbirth", "c"),
  make_burden_panel("SVN", "d")
)
panels_bcd[[2L]] <- panels_bcd[[2L]] + ggplot2::labs(
  x = "Attributable cases (log10 scale); side labels indicate AP (%)"
) + ggplot2::theme(
  axis.title.x = ggplot2::element_text(
    family = "serif", size = 11, margin = ggplot2::margin(6, 0, 0, 0)
  )
)

figure3 <- panel_a + panels_bcd[[1L]] + panels_bcd[[2L]] + panels_bcd[[3L]] +
  patchwork::plot_layout(widths = c(0.86, 1.25, 1.25, 1.25), guides = "collect")

save_png(figure3, "Figure3.png", width = 13.4, height = 6.3, dpi = 300)
