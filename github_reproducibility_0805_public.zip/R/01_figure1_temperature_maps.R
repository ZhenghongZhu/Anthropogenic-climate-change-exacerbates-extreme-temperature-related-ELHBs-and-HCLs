#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("ggplot2", "sf", "rnaturalearth", "patchwork", "viridis"))
load_figure_data("Figure1_plot_data.RData")

world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")
points <- sf::st_as_sf(
  figure1_temperature_data,
  coords = c("longitude", "latitude"), crs = 4326, remove = FALSE
)

make_panel <- function(category_column, title, breaks, labels) {
  ggplot2::ggplot() +
    ggplot2::geom_sf(
      data = points,
      ggplot2::aes(colour = .data[[category_column]]),
      size = 0.10, alpha = 0.60
    ) +
    ggplot2::geom_sf(data = world, fill = NA, colour = "black", linewidth = 0.22) +
    viridis::scale_colour_viridis(
      name = "Temperature (degC)", option = "magma", direction = -1,
      discrete = FALSE, breaks = breaks, labels = labels
    ) +
    ggplot2::coord_sf(xlim = c(-90, 130), ylim = c(-55, 55), expand = FALSE) +
    ggplot2::labs(title = title) +
    ggplot2::theme_minimal(base_family = "serif") +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 10.5, hjust = 0.5),
      legend.position = "bottom",
      legend.key.width = grid::unit(1.15, "cm"),
      legend.key.height = grid::unit(0.24, "cm"),
      legend.text = ggplot2::element_text(size = 8.5),
      legend.title = ggplot2::element_text(size = 8.5),
      panel.grid = ggplot2::element_blank(),
      axis.text = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.border = ggplot2::element_rect(colour = "black", linewidth = 0.7, fill = NA),
      plot.margin = ggplot2::margin(0, 2, 1, 2)
    )
}

plots <- list(
  make_panel(
    "panel_a_colour_category",
    "(a) Gestational temperature (ERA5-derived)", 1:5,
    c(20, 24, 26, 28, 32)
  ),
  make_panel(
    "panel_b_colour_category",
    "(b) Gestational temperature (Factual)", 1:5,
    c(20, 24, 26, 28, 32)
  ),
  make_panel(
    "panel_c_colour_category",
    "(c) Gestational temperature (Counterfactual)", 1:5,
    c(20, 24, 26, 28, 32)
  ),
  make_panel(
    "panel_d_colour_category",
    "(d) Anthropogenic warming (Factual - Counterfactual)", -1:3, -1:3
  )
)

figure1 <- patchwork::wrap_plots(plots, ncol = 2, guides = "keep")
save_png(figure1, "Figure1.png", width = 12, height = 7, dpi = 300)
