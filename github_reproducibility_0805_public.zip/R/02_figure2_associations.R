#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("ggplot2", "patchwork", "scales"))
load_figure_data("Figure2_plot_data.RData")

region_order <- figure2_plot_spec$region_order
outcome_order <- figure2_plot_spec$outcome_order
figure2_plot_data$region <- factor(
  figure2_plot_data$region, levels = rev(region_order)
)
figure2_plot_data$y <- as.numeric(figure2_plot_data$region)

colours <- c(
  "Heat >90th percentile" = "#D35C61",
  "Cold <10th percentile" = "#4A88B4"
)
panel_titles <- c(
  "Heat >90th percentile" = "(a) Association between heat exposure and early-life health",
  "Cold <10th percentile" = "(b) Association between cold exposure and early-life health"
)

table_panel <- function(exposure) {
  d <- unique(figure2_plot_data[
    figure2_plot_data$exposure == exposure,
    c("region", "row_type", "y")
  ])
  d$label <- as.character(d$region)
  d$label[d$label == "Latin American"] <- "Latin America"
  ggplot2::ggplot(d, ggplot2::aes(y = y)) +
    ggplot2::geom_text(
      ggplot2::aes(x = 0.02, label = label), hjust = 0,
      family = "serif", fontface = "bold", size = 4.0
    ) +
    ggplot2::annotate(
      "text", x = 0.02, y = 10.25, label = "Region", hjust = 0,
      family = "serif", fontface = "bold", size = 4.1
    ) +
    ggplot2::annotate("segment", x = 0, xend = 1, y = 9.65, yend = 9.65, linewidth = 0.45) +
    ggplot2::annotate("segment", x = 0, xend = 1, y = 1.5, yend = 1.5, linewidth = 0.45) +
    ggplot2::coord_cartesian(xlim = c(0, 1), ylim = c(0.5, 10.8), clip = "off") +
    ggplot2::labs(title = panel_titles[[exposure]]) +
    ggplot2::theme_void(base_family = "serif") +
    ggplot2::theme(
      plot.title = ggplot2::element_text(
        family = "serif", face = "bold", size = 10.5, hjust = 0,
        margin = ggplot2::margin(0, 0, 3, 0)
      ),
      panel.border = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.45),
      plot.margin = ggplot2::margin(0, 0, 0, 0)
    )
}

forest_panel <- function(exposure, outcome) {
  d <- figure2_plot_data[
    figure2_plot_data$exposure == exposure & figure2_plot_data$outcome == outcome,
  ]
  regional <- d[d$row_type == "Region", ]
  pooled <- d[d$row_type == "Pooled", ]
  polygon <- data.frame(
    x = c(pooled$lci, pooled$HR, pooled$uci, pooled$HR),
    y = c(pooled$y, pooled$y + 0.24, pooled$y, pooled$y - 0.24)
  )
  limits <- range(c(d$lci, d$uci, 1), finite = TRUE)
  pad <- diff(log(limits)) * 0.12
  limits <- exp(log(limits) + c(-pad, pad))
  ticks <- c(0.75, 1, 1.5, 2, 3, 5, 8)
  ticks <- ticks[ticks >= limits[1] & ticks <= limits[2]]

  ggplot2::ggplot(regional, ggplot2::aes(x = HR, y = y)) +
    ggplot2::geom_vline(xintercept = 1, linetype = "dashed", colour = "#707070", linewidth = 0.45) +
    ggplot2::geom_segment(
      ggplot2::aes(x = lci, xend = uci, y = y, yend = y),
      linewidth = 0.9, colour = colours[[exposure]]
    ) +
    ggplot2::geom_point(
      shape = 21, size = 3.0, stroke = 0.8,
      fill = "white", colour = colours[[exposure]]
    ) +
    ggplot2::geom_polygon(
      data = polygon, ggplot2::aes(x = x, y = y), inherit.aes = FALSE,
      fill = colours[[exposure]], colour = colours[[exposure]]
    ) +
    ggplot2::annotate("segment", x = limits[1], xend = limits[2], y = 1.5, yend = 1.5, linewidth = 0.45) +
    ggplot2::scale_x_log10(limits = limits, breaks = ticks, labels = scales::label_number(accuracy = 0.1)) +
    ggplot2::scale_y_continuous(limits = c(0.5, 10.8), breaks = NULL, expand = c(0, 0)) +
    ggplot2::labs(title = if (exposure == "Heat >90th percentile") outcome else NULL, x = NULL, y = NULL) +
    ggplot2::theme_classic(base_family = "serif", base_size = 12) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 15, hjust = 0.5),
      axis.text.x = ggplot2::element_text(size = 11),
      axis.line.y = ggplot2::element_blank(),
      axis.ticks.y = ggplot2::element_blank(),
      panel.border = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.45),
      plot.margin = ggplot2::margin(0, 0, 0, 0)
    )
}

exposure_block <- function(exposure) {
  pieces <- c(
    list(table_panel(exposure)),
    lapply(outcome_order, function(outcome) forest_panel(exposure, outcome))
  )
  patchwork::wrap_plots(pieces, nrow = 1, widths = c(1.22, 1, 1, 1))
}

legend <- ggplot2::ggplot(data.frame(
  x = c(1, 2), y = 1,
  label = c(
    "Heat: > country-specific 90th percentile",
    "Cold: < country-specific 10th percentile"
  ),
  colour = c("#D35C61", "#4A88B4")
), ggplot2::aes(x = x, y = y)) +
  ggplot2::geom_segment(
    ggplot2::aes(x = x - 0.12, xend = x + 0.12, yend = y, colour = colour),
    linewidth = 1.0, show.legend = FALSE
  ) +
  ggplot2::geom_point(
    ggplot2::aes(colour = colour), shape = 21, fill = "white",
    size = 3.2, stroke = 0.8, show.legend = FALSE
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = x + 0.18, label = label), hjust = 0,
    family = "serif", size = 4.0
  ) +
  ggplot2::annotate(
    "text", x = 1.78, y = 0.72, label = "HR (95% CI)",
    family = "serif", fontface = "bold", size = 4.2
  ) +
  ggplot2::scale_colour_identity() +
  ggplot2::coord_cartesian(xlim = c(0.75, 2.85), ylim = c(0.60, 1.08), clip = "off") +
  ggplot2::theme_void()

figure2 <- exposure_block("Heat >90th percentile") /
  exposure_block("Cold <10th percentile") /
  legend +
  patchwork::plot_layout(heights = c(1, 1, 0.14))

save_png(figure2, "Figure2.png", width = 11.5, height = 9.3, dpi = 300)
