#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")

checks <- list()
add_check <- function(section, item, manuscript_value, data_value,
                      tolerance = NA_real_, status = NULL, note = "") {
  difference <- suppressWarnings(as.numeric(data_value) - as.numeric(manuscript_value))
  if (is.null(status)) {
    status <- if (is.na(tolerance) || is.na(difference)) {
      "REVIEW"
    } else if (abs(difference) <= tolerance) {
      "PASS"
    } else {
      "MISMATCH"
    }
  }
  checks[[length(checks) + 1L]] <<- data.frame(
    section = section,
    item = item,
    manuscript_value = as.character(manuscript_value),
    data_value = as.character(data_value),
    difference = if (is.na(difference)) "" else format(difference, digits = 8),
    status = status,
    note = note,
    stringsAsFactors = FALSE
  )
}

load_figure_data("Figure1_plot_data.RData")
load_figure_data("Figure2_model_results.RData")
load_figure_data("Figure3_plot_data.RData")
load_figure_data("Figure4_plot_data.RData")
load_figure_data("Figure5_plot_data.RData")
load_figure_data("ExtendedDataFigure3_plot_data.RData")

# Study population and Figure 2 model targets.
expected_counts <- c(Pregnancies = 1527281, Miscarriage = 131283,
                     Stillbirth = 34747, SVN = 268250)
for (name in names(expected_counts)) {
  value <- figure2_manuscript_counts$value[figure2_manuscript_counts$measure == name]
  add_check("Study population", name, expected_counts[[name]], value, 0)
}

if (file.exists(file.path(repo_root(), "data-restricted", "Figure2_model_input.RData"))) {
  restricted <- new.env(parent = emptyenv())
  load(file.path(repo_root(), "data-restricted", "Figure2_model_input.RData"), envir = restricted)
  add_check("Restricted model input", "Pregnancies", 1527281,
            restricted$model_input_counts$pregnancies, 0)
  outcome_counts <- setNames(
    restricted$model_input_counts$by_outcome$Freq,
    restricted$model_input_counts$by_outcome$Var1
  )
  add_check("Restricted model input", "Miscarriage", 131283,
            outcome_counts[["miscarriage"]], 0)
  add_check("Restricted model input", "Stillbirth", 34747,
            outcome_counts[["stillbirth"]], 0)
  add_check("Restricted model input", "SVN", 268250,
            outcome_counts[["small vulnerable newborn"]], 0)
}

smoke_test_file <- file.path(
  repo_root(), "data-restricted",
  "Figure2_refitted_model_results_Central_Asia_Europe.RData"
)
if (file.exists(smoke_test_file)) {
  smoke <- new.env(parent = emptyenv())
  load(smoke_test_file, envir = smoke)
  published_region <- subset(
    figure2_regional_estimates,
    region == "Central Asia & Europe"
  )
  for (i in seq_len(nrow(smoke$regional_hr))) {
    d <- smoke$regional_hr[i, ]
    target <- subset(
      published_region,
      exposure == d$exposure & outcome == d$outcome
    )
    prefix <- paste(d$exposure, d$outcome)
    add_check("Figure 2 model smoke test", paste(prefix, "HR"),
              target$HR, d$HR, 0.005)
    add_check("Figure 2 model smoke test", paste(prefix, "lower CI"),
              target$lci, d$lci, 0.005)
    add_check("Figure 2 model smoke test", paste(prefix, "upper CI"),
              target$uci, d$uci, 0.005)
  }
}

expected_hr <- data.frame(
  exposure = rep(c("Heat >90th percentile", "Cold <10th percentile"), each = 3),
  outcome = rep(c("Miscarriage", "Stillbirth", "SVN"), 2),
  HR = c(2.71, 1.77, 1.21, 2.37, 1.75, 1.16),
  lci = c(2.01, 1.37, 1.08, 1.61, 1.24, 0.97),
  uci = c(3.65, 2.27, 1.36, 3.48, 2.46, 1.38)
)
for (i in seq_len(nrow(expected_hr))) {
  observed <- subset(
    figure2_pooled_estimates,
    exposure == expected_hr$exposure[[i]] & outcome == expected_hr$outcome[[i]]
  )
  prefix <- paste(expected_hr$exposure[[i]], expected_hr$outcome[[i]])
  add_check("Figure 2 pooled HR", paste(prefix, "HR"), expected_hr$HR[[i]], observed$HR, 0.005)
  add_check("Figure 2 pooled HR", paste(prefix, "lower CI"), expected_hr$lci[[i]], observed$lci, 0.005)
  add_check("Figure 2 pooled HR", paste(prefix, "upper CI"), expected_hr$uci[[i]], observed$uci, 0.005)
}

# Figure 1 source distinction.
era5 <- figure1_temperature_data$ERA5_derived_C
factual <- figure1_temperature_data$factual_C
source_correlation <- cor(era5, factual, use = "complete.obs")
source_mad <- mean(abs(era5 - factual), na.rm = TRUE)
add_check(
  "Figure 1", "ERA5-derived and factual values are distinct", "not identical",
  if (identical(era5, factual)) "identical" else "not identical",
  status = if (identical(era5, factual)) "MISMATCH" else "PASS",
  note = sprintf("Pearson r = %.4f; mean absolute difference = %.3f degC.",
                 source_correlation, source_mad)
)

# Figure 3 total attribution labels.
expected_ap <- data.frame(
  panel = rep(c("Miscarriage", "Stillbirth", "SVN"), each = 2),
  exposure = rep(c("heat", "cold"), 3),
  ap = c(73.0, -52.2, 74.6, -55.3, 75.5, -58.5)
)
for (i in seq_len(nrow(expected_ap))) {
  observed <- subset(
    figure3_scenario_cases,
    region == "Total" & panel == expected_ap$panel[[i]] &
      exposure == expected_ap$exposure[[i]]
  )$ap_signed_percent[[1L]]
  add_check(
    "Figure 3 attributable proportion",
    paste(expected_ap$panel[[i]], expected_ap$exposure[[i]]),
    expected_ap$ap[[i]], observed, 0.05
  )
}
se_asia_svn_heat <- subset(
  figure3_scenario_cases,
  region == "Southeast Asia" & panel == "SVN" & exposure == "heat"
)$ap_signed_percent[[1L]]
add_check(
  "Figure 3 direction audit", "Southeast Asia heat-related SVN AP",
  "positive under current attribution interpretation", se_asia_svn_heat,
  status = if (se_asia_svn_heat < 0) "REVIEW" else "PASS",
  note = "The current source and embedded manuscript figure display -90.9%; verify the sign against the factual and counterfactual case columns."
)

# Figure 4 country-level statements.
hcl_targets <- data.frame(
  country = c("Egypt", "Nepal", "Pakistan", "Nepal", "Pakistan", "Nepal", "Pakistan"),
  exposure = "heat",
  dimension = c("health", "health", "health", "cognitive", "cognitive",
                "non-cognitive", "non-cognitive"),
  value = c(38.8, 29.3, 27.2, 74.9, 69.9, 0.230, 0.214)
)
for (i in seq_len(nrow(hcl_targets))) {
  d <- hcl_targets[i, ]
  observed <- subset(
    figure4_hcl_data,
    Country == d$country & exposure == d$exposure & dimension == d$dimension
  )$map_value[[1L]]
  add_check(
    "Figure 4 country value",
    paste(d$country, d$dimension), d$value, observed,
    if (d$dimension == "non-cognitive") 0.0005 else 0.05
  )
}
for (dim_name in c("health", "cognitive", "non-cognitive")) {
  observed <- nrow(subset(
    figure4_hcl_data,
    exposure == "cold" & dimension == dim_name & map_value > 0
  ))
  expected <- if (dim_name == "health") 24 else 18
  add_check("Figure 4 country count", paste("Cold-related", dim_name), expected, observed, 0)
}

# Figure 5 aggregate and country-level statements.
sum_cost <- function(exposure) {
  sum(subset(figure5_cost_data, exposure == exposure & metric == "absolute")$map_value)
}
add_check("Figure 5 aggregate cost", "Heat-related cost, US$ billions", 469.7,
          sum(subset(figure5_cost_data, exposure == "heat" & metric == "absolute")$map_value), 0.05)
add_check("Figure 5 aggregate cost", "Cold-related cost, US$ billions", 14.7,
          sum(subset(figure5_cost_data, exposure == "cold" & metric == "absolute")$map_value), 0.05)
add_check("Figure 5 aggregate cost", "Total cost, US$ billions", 484.4,
          sum(subset(figure5_cost_data, exposure == "net" & metric == "absolute")$map_value), 0.05)

cost_targets <- data.frame(
  country = c("India", "India", "Egypt", "Pakistan", "Nigeria", "Pakistan",
              "India", "Bangladesh", "Egypt", "Nepal", "Pakistan", "Mali", "Burkina Faso"),
  exposure = c("heat", "net", "net", "net", "net", "cold", "cold", "cold",
               rep("net", 5)),
  metric = c(rep("absolute", 8), rep("relative", 5)),
  value = c(181.5, 184.2, 61.3, 44.5, 43.1, 6.8, 2.7, 1.5,
            18.6, 15.6, 14.8, 14.2, 12.6)
)
for (i in seq_len(nrow(cost_targets))) {
  d <- cost_targets[i, ]
  observed <- subset(
    figure5_cost_data,
    Country == d$country & exposure == d$exposure & metric == d$metric
  )$map_value[[1L]]
  add_check(
    "Figure 5 country value",
    paste(d$country, d$exposure, d$metric), d$value, observed, 0.05
  )
}

# Extended Data Figure 3 endpoint labels are crude manuscript percentages,
# whereas the plotted trajectories are modelled/staged cumulative probabilities.
endpoint <- aggregate(
  component_cumulative_probability_percent ~ outcome,
  data = extended3_cumulative_probability,
  FUN = function(x) tail(x, 1L)
)
expected_endpoint <- c(Miscarriage = 8.6, Stillbirth = 2.3, SVN = 17.6)
for (outcome in names(expected_endpoint)) {
  observed <- endpoint$component_cumulative_probability_percent[endpoint$outcome == outcome]
  add_check(
    "Extended Data Figure 3", paste(outcome, "final cumulative probability"),
    expected_endpoint[[outcome]], observed, 0.40,
    note = "The legend reports the crude study percentage; the trajectory is modelled data."
  )
}

# Wording and numbering items that require manuscript revision, not data changes.
manual_reviews <- data.frame(
  section = "Manuscript wording",
  item = c(
    "Figure 1 caption",
    "Figure 2 caption",
    "Methods cross-reference",
    "Results map cross-references",
    "DHS clustering description",
    "Conception season adjustment",
    "Extended Data Figure 3 caption"
  ),
  manuscript_value = c(
    "Observed mean temperature",
    "Table reports regional thresholds and reference ranges",
    "Extended Data Fig. 5",
    "Maps cited as Extended Data Figs. 2 and 3",
    "DHS clusters incorporated as random intercepts",
    "Warm/cold conception season",
    "Observed cumulative probabilities"
  ),
  data_value = c(
    "ERA5-derived gestational temperature",
    "Current figure omits threshold and reference-range table columns",
    "Only Extended Data Figs. 1-3 are present; framework is Extended Data Fig. 3",
    "Map panels are main Figs. 4 and 5 in the current manuscript",
    "coxph(..., id = cluster_id) supplies cluster-robust variance, not a random intercept",
    "Reconstruction code uses ns(conception_month, 4)",
    "Modelled cumulative probabilities"
  ),
  note = c(
    "Align caption with the final panel title.",
    "Remove the obsolete sentence or restore those columns.",
    "Correct the figure number.",
    "Correct the figure citations after confirming final numbering.",
    "Revise Methods or refit with a frailty/random-effect specification.",
    "Revise Methods or refit using the stated warm/cold season variable.",
    "Use modelled/estimated rather than observed."
  ),
  stringsAsFactors = FALSE
)
for (i in seq_len(nrow(manual_reviews))) {
  d <- manual_reviews[i, ]
  add_check(d$section, d$item, d$manuscript_value, d$data_value,
            status = "REVIEW", note = d$note)
}

result <- do.call(rbind, checks)
output_csv <- file.path(repo_root(), "docs", "crosscheck_results.csv")
write.csv(result, output_csv, row.names = FALSE, fileEncoding = "UTF-8")

summary_counts <- table(result$status)
review_rows <- result[result$status != "PASS", ]
markdown <- c(
  "# Manuscript cross-check",
  "",
  "Manuscript checked: `manuscript-climate+change+and+early-life+0805.docx`.",
  "",
  sprintf("Automated checks: %d PASS, %d REVIEW, %d MISMATCH.",
          ifelse("PASS" %in% names(summary_counts), summary_counts[["PASS"]], 0),
          ifelse("REVIEW" %in% names(summary_counts), summary_counts[["REVIEW"]], 0),
          ifelse("MISMATCH" %in% names(summary_counts), summary_counts[["MISMATCH"]], 0)),
  "",
  "The complete machine-readable audit is in `crosscheck_results.csv`.",
  "",
  "## Items requiring author review",
  ""
)
if (nrow(review_rows)) {
  for (i in seq_len(nrow(review_rows))) {
    markdown <- c(
      markdown,
      paste0("- **", review_rows$item[[i]], "**: ", review_rows$note[[i]],
             " Manuscript: `", review_rows$manuscript_value[[i]],
             "`; packaged data/code: `", review_rows$data_value[[i]], "`.")
    )
  }
} else {
  markdown <- c(markdown, "- None.")
}
writeLines(markdown, file.path(repo_root(), "docs", "MANUSCRIPT_CROSSCHECK.md"), useBytes = TRUE)

if (any(result$status == "MISMATCH")) quit(status = 1L)
message("Cross-check completed: ", output_csv)
