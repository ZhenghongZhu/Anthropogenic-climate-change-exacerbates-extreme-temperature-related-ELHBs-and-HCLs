#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("ggplot2", "patchwork"))
load_figure_data("ExtendedDataFigure1_plot_data.RData")

region_order <- c(
  "East Africa", "Southern Africa", "West Africa", "West Asia&North Africa",
  "South Asia", "Southeast Asia", "Central Asia&Europe", "Latin American"
)
region_labels <- c(
  "East Africa" = "East Africa",
  "Southern Africa" = "Southern Africa",
  "West Africa" = "West Africa",
  "West Asia&North Africa" = "West Asia &\nNorth Africa",
  "South Asia" = "South Asia",
  "Southeast Asia" = "Southeast Asia",
  "Central Asia&Europe" = "Central Asia &\nEurope",
  "Latin American" = "Latin America"
)
outcomes <- c("Miscarriage", "Stillbirth", "SVN")
outcome_colours <- c(
  "Miscarriage" = "#440154", "Stillbirth" = "#B13F2F", "SVN" = "#D6A21E"
)
outcome_tags <- c("Miscarriage" = "(a)", "Stillbirth" = "(b)", "SVN" = "(c)")

make_region_panel <- function(region, outcome, index) {
  curve <- extended1_curves[
    extended1_curves$region == region & extended1_curves$outcome == outcome,
  ]
  hist <- extended1_histograms[
    extended1_histograms$region == region & extended1_histograms$outcome == outcome,
  ]
  colour <- outcome_colours[[outcome]]
  y_limits <- range(c(curve$lci, curve$uci, 1), na.rm = TRUE)
  y_pad <- max(diff(y_limits) * 0.10, 0.03)
  y_limits <- c(max(0.05, y_limits[1] - y_pad), y_limits[2] + y_pad)

  curve_plot <- ggplot2::ggplot(curve, ggplot2::aes(x = temperature, y = HR)) +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = lci, ymax = uci), fill = colour, alpha = 0.16) +
    ggplot2::geom_line(colour = colour, linewidth = 0.85) +
    ggplot2::geom_hline(yintercept = 1, linetype = "dashed", colour = "#777777", linewidth = 0.35) +
    ggplot2::scale_y_continuous(limits = y_limits) +
    ggplot2::labs(
      title = if (index == 1L) {
        paste(outcome_tags[[outcome]], outcome, "\n", region_labels[[region]])
      } else {
        region_labels[[region]]
      },
      x = NULL, y = NULL
    ) +
    ggplot2::theme_classic(base_family = "serif", base_size = 10) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(size = 10.5, hjust = 0.5),
      axis.text.x = ggplot2::element_blank(),
      axis.ticks.x = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_text(size = 8.5),
      plot.margin = ggplot2::margin(1, 2, 0, 2)
    )

  hist_plot <- ggplot2::ggplot(hist, ggplot2::aes(x = bin_mid, y = scaled_count)) +
    ggplot2::geom_col(
      width = median(hist$bin_upper - hist$bin_lower, na.rm = TRUE) * 0.95,
      fill = colour, alpha = 0.18, colour = colour, linewidth = 0.15
    ) +
    ggplot2::scale_y_continuous(expand = c(0, 0)) +
    ggplot2::labs(x = NULL, y = NULL) +
    ggplot2::theme_classic(base_family = "serif", base_size = 10) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(size = 8.5),
      axis.text.y = ggplot2::element_blank(),
      axis.ticks.y = ggplot2::element_blank(),
      axis.line.y = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(0, 2, 1, 2)
    )

  curve_plot / hist_plot + patchwork::plot_layout(heights = c(3.2, 0.75))
}

make_outcome_block <- function(outcome) {
  panels <- lapply(seq_along(region_order), function(index) {
    make_region_panel(region_order[[index]], outcome, index)
  })
  patchwork::wrap_plots(panels, ncol = 4)
}

axis_caption <- ggplot2::ggplot() +
  ggplot2::annotate(
    "text", x = 0.5, y = 0.5, label = "Gestational mean temperature (degC)",
    family = "serif", size = 4.5
  ) +
  ggplot2::theme_void()

extended_figure1 <- (make_outcome_block("Miscarriage") /
  make_outcome_block("Stillbirth") /
  make_outcome_block("SVN") /
  axis_caption) + patchwork::plot_layout(heights = c(1, 1, 1, 0.035))

save_png(extended_figure1, "ExtendedDataFigure1.png", width = 8.5, height = 11.4, dpi = 300)
