#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
root <- repo_root()

scripts <- c(
  "01_figure1_temperature_maps.R",
  "02_figure2_associations.R",
  "03_figure3_attribution.R",
  "04_figure4_human_capital_maps.R",
  "05_figure5_economic_cost_maps.R",
  "06_extended_data_figure1_exposure_response.R",
  "08_extended_data_figure3_multistate_framework.R"
)

for (script in scripts) {
  path <- file.path(root, "R", script)
  message("Running ", script)
  script_env <- new.env(parent = globalenv())
  tryCatch(
    sys.source(path, envir = script_env),
    error = function(e) stop("Figure script failed: ", script, "\n", conditionMessage(e))
  )
}

message("All manuscript figures were generated in outputs/reproduced.")
