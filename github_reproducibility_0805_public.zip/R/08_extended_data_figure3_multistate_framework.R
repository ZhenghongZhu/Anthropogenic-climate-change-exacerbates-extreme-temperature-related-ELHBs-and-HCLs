#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("ggplot2", "patchwork"))
load_figure_data("ExtendedDataFigure3_plot_data.RData")

title_theme <- ggplot2::theme(
  plot.title = ggplot2::element_text(
    family = "serif", face = "bold", size = 13.5, hjust = 0,
    margin = ggplot2::margin(0, 0, 4, 0)
  )
)

# Panel b: modelled cumulative probabilities shown as stacked lines.
cum <- extended3_cumulative_probability
cum$outcome <- factor(cum$outcome, levels = c("Miscarriage", "Stillbirth", "SVN"))
colours <- c("Miscarriage" = "#440154", "Stillbirth" = "#B13F2F", "SVN" = "#D6A21E")
shapes <- c("Miscarriage" = 16, "Stillbirth" = 15, "SVN" = 17)
legend_labels <- c(
  "Miscarriage" = "Miscarriage, 8.6%",
  "Stillbirth" = "Stillbirth, 2.3%",
  "SVN" = "SVN, 17.6%"
)
panel_b <- ggplot2::ggplot(
  cum,
  ggplot2::aes(
    x = time_month, y = stacked_line_y_percent,
    colour = outcome, shape = outcome, group = outcome
  )
) +
  ggplot2::geom_line(linewidth = 0.8) +
  ggplot2::geom_point(size = 2.2) +
  ggplot2::scale_colour_manual(values = colours, labels = legend_labels) +
  ggplot2::scale_shape_manual(values = shapes, labels = legend_labels) +
  ggplot2::scale_x_continuous(breaks = 0:11) +
  ggplot2::scale_y_continuous(limits = c(0, 30), breaks = seq(0, 30, 5), expand = c(0, 0)) +
  ggplot2::labs(
    title = "(b) Modelled cumulative probability across pregnancy",
    x = "Gestational month", y = "Cumulative probability (%)",
    colour = NULL, shape = NULL
  ) +
  ggplot2::theme_classic(base_family = "serif", base_size = 11) +
  ggplot2::theme(
    legend.position = c(0.04, 0.96),
    legend.justification = c(0, 1),
    legend.background = ggplot2::element_rect(fill = "white", colour = NA),
    axis.title = ggplot2::element_text(size = 11.5),
    panel.grid = ggplot2::element_line(colour = "#ECECEC", linewidth = 0.25)
  ) + title_theme

# Panel c: single-outcome versus multistate pooled estimates.
comparison <- extended3_model_comparison
comparison$outcome <- factor(comparison$outcome, levels = rev(c("Miscarriage", "Stillbirth", "SVN")))
comparison$exposure <- factor(
  comparison$exposure,
  levels = c("Heat >90th percentile", "Cold <10th percentile")
)
comparison$model <- factor(
  comparison$model,
  levels = c("Single-outcome Cox", "Multistate model (Fig. 2)")
)
comparison$y <- as.numeric(comparison$outcome) + ifelse(
  comparison$model == "Single-outcome Cox", 0.10, -0.10
)
comparison$exposure_colour <- ifelse(
  comparison$exposure == "Heat >90th percentile", "#D35C61", "#4A88B4"
)
p_text <- merge(
  extended3_model_difference_p,
  unique(comparison[c("exposure", "outcome")]),
  by = c("exposure", "outcome")
)
p_text$outcome <- factor(p_text$outcome, levels = levels(comparison$outcome))
single <- subset(comparison, model == "Single-outcome Cox")
multistate <- subset(comparison, model == "Multistate model (Fig. 2)")

panel_c <- ggplot2::ggplot(comparison, ggplot2::aes(x = HR, y = y)) +
  ggplot2::geom_vline(xintercept = 1, linetype = "dotted", colour = "#777777") +
  ggplot2::geom_segment(
    data = single,
    ggplot2::aes(x = lci, xend = uci, y = y, yend = y, colour = exposure),
    linewidth = 0.8
  ) +
  ggplot2::geom_segment(
    data = multistate,
    ggplot2::aes(x = lci, xend = uci, y = y, yend = y),
    linewidth = 0.8, linetype = "dashed", colour = "#303030"
  ) +
  ggplot2::geom_point(
    data = single,
    ggplot2::aes(colour = exposure), shape = 18, size = 3.3
  ) +
  ggplot2::geom_point(
    data = multistate,
    shape = 23, size = 3.3, fill = "white", colour = "#303030", stroke = 0.9
  ) +
  ggplot2::geom_text(
    data = p_text,
    ggplot2::aes(x = 4.6, y = as.numeric(outcome), label = p_label),
    inherit.aes = FALSE, family = "serif", size = 3.1, hjust = 1
  ) +
  ggplot2::scale_colour_manual(values = c(
    "Heat >90th percentile" = "#D35C61",
    "Cold <10th percentile" = "#4A88B4"
  ), guide = "none") +
  ggplot2::scale_x_log10(limits = c(0.75, 5), breaks = c(1, 1.5, 2, 3, 5)) +
  ggplot2::scale_y_continuous(
    breaks = seq_along(levels(comparison$outcome)),
    labels = levels(comparison$outcome)
  ) +
  ggplot2::facet_grid(. ~ exposure) +
  ggplot2::labs(
    title = "(c) Separate analyses versus multistate model",
    x = "Hazard ratio (95% CI, log scale)", y = NULL,
    caption = "Solid diamond: single-outcome Cox model; open diamond: multistate model"
  ) +
  ggplot2::theme_classic(base_family = "serif", base_size = 10.5) +
  ggplot2::theme(
    strip.background = ggplot2::element_rect(fill = "white", colour = "black"),
    strip.text = ggplot2::element_text(face = "bold", size = 10),
    panel.border = ggplot2::element_rect(fill = NA, colour = "black", linewidth = 0.4),
    axis.title.x = ggplot2::element_text(size = 10.5),
    plot.caption = ggplot2::element_text(size = 8.5, hjust = 0.5)
  ) + title_theme

# Only the data-driven panels are included in the public reproducibility package.
extended_figure3_bc <- panel_b / panel_c +
  patchwork::plot_layout(heights = c(0.95, 1.05))
save_png(
  extended_figure3_bc,
  "ExtendedDataFigure3_panels_b_c.png",
  width = 9.6,
  height = 8.4,
  dpi = 300
)
