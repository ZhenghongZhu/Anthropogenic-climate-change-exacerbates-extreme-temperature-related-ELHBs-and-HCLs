# Manuscript cross-check

Manuscript checked: `manuscript-climate+change+and+early-life+0805.docx`.

Automated checks: 80 PASS, 8 REVIEW, 0 MISMATCH.

The complete machine-readable audit is in `crosscheck_results.csv`.

## Items requiring author review

- **Southeast Asia heat-related SVN AP**: The current source and embedded manuscript figure display -90.9%; verify the sign against the factual and counterfactual case columns. Manuscript: `positive under current attribution interpretation`; packaged data/code: `-90.8867437397504`.
- **Figure 1 caption**: Align caption with the final panel title. Manuscript: `Observed mean temperature`; packaged data/code: `ERA5-derived gestational temperature`.
- **Figure 2 caption**: Remove the obsolete sentence or restore those columns. Manuscript: `Table reports regional thresholds and reference ranges`; packaged data/code: `Current figure omits threshold and reference-range table columns`.
- **Methods cross-reference**: Correct the figure number. Manuscript: `Extended Data Fig. 5`; packaged data/code: `Only Extended Data Figs. 1-3 are present; framework is Extended Data Fig. 3`.
- **Results map cross-references**: Correct the figure citations after confirming final numbering. Manuscript: `Maps cited as Extended Data Figs. 2 and 3`; packaged data/code: `Map panels are main Figs. 4 and 5 in the current manuscript`.
- **DHS clustering description**: Revise Methods or refit with a frailty/random-effect specification. Manuscript: `DHS clusters incorporated as random intercepts`; packaged data/code: `coxph(..., id = cluster_id) supplies cluster-robust variance, not a random intercept`.
- **Conception season adjustment**: Revise Methods or refit using the stated warm/cold season variable. Manuscript: `Warm/cold conception season`; packaged data/code: `Reconstruction code uses ns(conception_month, 4)`.
- **Extended Data Figure 3 caption**: Use modelled/estimated rather than observed. Manuscript: `Observed cumulative probabilities`; packaged data/code: `Modelled cumulative probabilities`.
