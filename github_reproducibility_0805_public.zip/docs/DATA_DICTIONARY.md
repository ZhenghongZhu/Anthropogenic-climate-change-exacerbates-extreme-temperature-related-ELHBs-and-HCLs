# Data dictionary

## Public figure data

### `Figure1_plot_data.RData`

- `figure1_temperature_data`: public 0.5-degree grid summaries for ERA5-derived,
  factual, counterfactual, and factual-minus-counterfactual gestational
  temperatures. Pregnancy IDs, DHS cluster IDs, and exact cluster coordinates
  are excluded. `source_records` gives the number of local plotting records
  represented by each grid cell.
- `figure1_panel_spec`: panel titles and source columns.
- `figure1_common_breaks`, `figure1_difference_breaks`: legend breaks.

### `Figure2_plot_data.RData`

- `figure2_regional_estimates`: region, exposure, outcome, HR, and 95% CI.
- `figure2_pooled_estimates`: REML random-effects pooled HRs and 95% CIs.
- `figure2_plot_data`: combined regional and pooled plotting records.
- `figure2_plot_spec`: region order, outcomes, and exposure definitions.

### `Figure2_model_results.RData`

- `figure2_full_model_coefficients`: full region-specific Cox coefficient tables.
- `figure2_heat_transition_coefficients`: extracted heat-transition terms.
- `figure2_regional_estimates`, `figure2_pooled_estimates`: Figure 2 HR inputs.
- `figure2_model_specification`: model formula, transition structure, reference
  category, percentile definitions, and pooling method.
- `figure2_manuscript_counts`: analytic sample and outcome counts.

### `Figure3_plot_data.RData`

- `figure3_outcome_rates`: outcome cases per 1,000 pregnancies by region.
- `figure3_scenario_cases`: factual and natural-forcing counterfactual case
  estimates, signed plotting positions, and AP labels by outcome and exposure.
- `figure3_plot_spec`: panel and region order.

### `Figure4_plot_data.RData`

- `figure4_hcl_data`: country-level health, cognitive, and non-cognitive HCL
  estimates for heat, cold, and total loss, with lower and upper intervals,
  pregnancy denominators, and map-standardized values.
- `figure4_scale_spec`: fixed colour-class thresholds.

### `Figure5_plot_data.RData`

- `figure5_cost_data`: country-level absolute cost in 2015 US$ billions and
  relative cost as percentage of 2015 GDP for heat, cold, and total loss, with
  lower and upper intervals.
- `figure5_scale_spec`: fixed colour-class thresholds.

### `ExtendedDataFigure1_plot_data.RData`

- `extended1_curves`: region- and outcome-specific spline predictions, HRs,
  95% CIs, reference temperatures, and analysis ranges.
- `extended1_histograms`: temperature-distribution histogram data.
- `extended1_model_summary`, `extended1_model_specification`: model metadata.

### `ExtendedDataFigure3_plot_data.RData`

- `extended3_cumulative_probability`: modelled cumulative probability and
  stacked line position by gestational month and outcome.
- `extended3_model_comparison`: single-outcome Cox and multistate HRs and CIs.
- `extended3_model_difference_p`: between-model heterogeneity P values.

This file supports only panels b and c. The conceptual panels a and d are not
part of the public R reproducibility materials.

## Access-controlled model data

### `data-restricted/Figure2_model_input.RData`

This local file contains `model_data`, `model_input_dictionary`, and
`model_input_counts`. Cluster identifiers are pseudonymized and direct names,
coordinates, and reproductive-calendar strings are excluded. It remains
DHS-derived microdata and must not be committed to a public repository.
