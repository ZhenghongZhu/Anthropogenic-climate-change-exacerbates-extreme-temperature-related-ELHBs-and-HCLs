# Access-controlled Figure 2 model input

`Figure2_model_input.RData` is generated locally from authorized DHS-derived
analytic data with:

```r
Rscript R/09_build_restricted_model_input.R "path/to/data_analysis_clean.csv"
```

In RStudio, open `early-life-reproducibility.Rproj` and run:

```r
options(earlylife.dhs_analytic_csv = "path/to/data_analysis_clean.csv")
source("R/09_build_restricted_model_input.R")
```

The file contains only variables needed for the multistate Cox models and uses
a pseudonymized cluster identifier. It is nevertheless derived from DHS
microdata and is excluded from the public Git repository by `.gitignore`.

The exact region-specific and pooled model results required to reproduce Figure
2 are available publicly in `data/Figure2_model_results.RData`.

`Figure1_plot_data_exact.RData` is also retained locally because it contains
exact DHS-derived plotting coordinates. The public Figure 1 object is a
0.5-degree aggregate created with `R/12_build_public_figure1_data.R`.
