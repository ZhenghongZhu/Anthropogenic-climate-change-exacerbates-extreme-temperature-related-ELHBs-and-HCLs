# Release validation

Validation date: 4 September 2026

## Public workflow

The release was tested from the repository root with:

```bash
Rscript R/run_all_figures.R
```

The command completed successfully on 64-bit Microsoft Windows 10
(10.0.19045) with R 4.4.2. It generated seven non-empty PNG files in
`outputs/reproduced/`:

- `Figure1.png`
- `Figure2.png`
- `Figure3.png`
- `Figure4.png`
- `Figure5.png`
- `ExtendedDataFigure1.png`
- `ExtendedDataFigure3_panels_b_c.png`

The complete workflow took 21-24 seconds after all packages were installed.
It was tested both from the original directory containing non-ASCII characters
and from a clean directory created by extracting the release ZIP.

## Automated checks

`R/11_validate_release.R` confirmed the expected dimensions, country count,
exposure categories and outcome domains in the public Figure 4 and Figure 5
objects. It also confirmed the principal manuscript values, including:

- heat-related economic cost: US$467.2 billion;
- cold-related economic cost: US$14.2 billion;
- total economic cost: US$481.4 billion;
- India heat-related cost: US$180.2 billion;
- India total cost: US$182.8 billion; and
- total cost relative to GDP: 18.6% in Egypt, 15.3% in Nepal and 14.7% in Pakistan.

All numeric assertions passed within the tolerances specified in the script.

## Simulated individual-level model test

The public synthetic input was regenerated with:

```r
source("R/07_generate_figure2_simulated_input.R")
```

It contains 48,000 fully synthetic pregnancy records across eight regions. The
complete multistate Cox workflow was then executed with:

```r
source("R/10_figure2_multistate_model.R")
```

The eight-region demonstration completed in approximately 16 seconds and
returned 48 region-specific and six pooled heat- and cold-related estimates,
with no missing HR or confidence-limit values. A single-region test completed
in approximately 4 seconds. These estimates validate software execution only
and are not manuscript results.

## Data and privacy checks

The public `.RData` files contain aggregated or de-identified figure-level
objects. The release contains no individual-level DHS analytic data, pregnancy
identifiers, cluster identifiers, exact DHS coordinates, credentials, API keys
or machine-specific absolute paths. Restricted inputs are documented in
`data-restricted/README.md` and excluded by `.gitignore`.

## Scope

The public workflow fully reproduces the supplied quantitative figures from
the released plotting objects. The Figure 2 model code can be executed using
the public synthetic input, but reproducing the manuscript HR estimates still
requires an authorized DHS-derived analytic file. The model specification and
restricted-data preparation code are supplied in
`R/09_build_restricted_model_input.R` and
`R/10_figure2_multistate_model.R`.

The checked-in Figure 4 and Figure 5 plotting objects reflect 500 Monte Carlo
draws in the upstream analysis. The plotting workflow does not regenerate
those draws.
