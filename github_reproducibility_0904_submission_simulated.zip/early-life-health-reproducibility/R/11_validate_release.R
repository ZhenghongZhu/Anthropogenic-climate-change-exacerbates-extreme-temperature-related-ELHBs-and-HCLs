#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")

assert_close <- function(actual, expected, tolerance, label) {
  if (length(actual) != 1L || is.na(actual) || abs(actual - expected) > tolerance) {
    stop(
      label, " failed: expected ", expected,
      " +/- ", tolerance, ", observed ", paste(actual, collapse = ", ")
    )
  }
}

expected_outputs <- c(
  "Figure1.png", "Figure2.png", "Figure3.png", "Figure4.png",
  "Figure5.png", "ExtendedDataFigure1.png",
  "ExtendedDataFigure3_panels_b_c.png"
)
output_paths <- file.path(repo_root(), "outputs", "reproduced", expected_outputs)
if (any(!file.exists(output_paths))) {
  stop(
    "Missing reproduced figure file(s): ",
    paste(expected_outputs[!file.exists(output_paths)], collapse = ", ")
  )
}
if (any(file.info(output_paths)$size <= 0)) {
  stop("One or more reproduced figure files are empty.")
}

load_figure_data("Figure1_plot_data.RData")
stopifnot(
  nrow(figure1_temperature_data) == 6706L,
  all(c(
    "ERA5_derived_C", "factual_C", "counterfactual_C",
    "anthropogenic_warming_C"
  ) %in% names(figure1_temperature_data)),
  any(abs(
    figure1_temperature_data$ERA5_derived_C -
      figure1_temperature_data$factual_C
  ) > 1e-8, na.rm = TRUE)
)
assert_close(
  max(abs(
    figure1_temperature_data$anthropogenic_warming_C -
      (figure1_temperature_data$factual_C -
        figure1_temperature_data$counterfactual_C)
  ), na.rm = TRUE),
  0, 1e-10, "Figure 1 anthropogenic-warming identity"
)

load_figure_data("Figure2_plot_data.RData")
stopifnot(
  nrow(figure2_regional_estimates) == 48L,
  nrow(figure2_pooled_estimates) == 6L,
  length(unique(figure2_regional_estimates$region)) == 8L
)

load_figure_data("Figure2_simulated_model_input.RData")
stopifnot(
  nrow(model_data) == 48000L,
  ncol(model_data) == 19L,
  length(unique(model_data$region)) == 8L,
  all(c(
    "miscarriage", "stillbirth", "small vulnerable newborn", "term birth"
  ) %in% levels(model_data$outcome)),
  identical(simulation_specification$seed, 20260904L),
  !anyNA(model_data)
)

load_figure_data("Figure3_plot_data.RData")
stopifnot(
  nrow(figure3_outcome_rates) == 48L,
  nrow(figure3_scenario_cases) == 108L
)

load_figure_data("ExtendedDataFigure1_plot_data.RData")
stopifnot(
  nrow(extended1_model_summary) == 8L,
  all(extended1_model_summary$converged)
)

load_figure_data("ExtendedDataFigure3_plot_data.RData")
stopifnot(
  nrow(extended3_cumulative_probability) == 36L,
  nrow(extended3_model_comparison) == 12L,
  nrow(extended3_model_difference_p) == 6L
)

load_figure_data("Figure4_plot_data.RData")
figure4 <- as.data.frame(figure4_hcl_data)

stopifnot(
  nrow(figure4) == 486L,
  length(unique(figure4$Country)) == 54L,
  setequal(unique(figure4$exposure), c("heat", "cold", "net")),
  setequal(
    unique(figure4$dimension),
    c("health", "cognitive", "non-cognitive")
  )
)

lookup_figure4 <- function(country, dimension) {
  figure4$map_value[
    figure4$Country == country &
      figure4$exposure == "heat" &
      figure4$dimension == dimension
  ]
}

assert_close(lookup_figure4("Egypt", "health"), 38.8, 0.1, "Egypt heat health HCL")
assert_close(lookup_figure4("Nepal", "health"), 29.3, 0.1, "Nepal heat health HCL")
assert_close(lookup_figure4("Pakistan", "health"), 27.2, 0.1, "Pakistan heat health HCL")
assert_close(lookup_figure4("Nepal", "cognitive"), 71.6, 0.1, "Nepal heat cognitive HCL")
assert_close(lookup_figure4("Pakistan", "cognitive"), 66.8, 0.1, "Pakistan heat cognitive HCL")
assert_close(lookup_figure4("Nepal", "non-cognitive"), 0.220, 0.001, "Nepal heat non-cognitive HCL")
assert_close(lookup_figure4("Pakistan", "non-cognitive"), 0.205, 0.001, "Pakistan heat non-cognitive HCL")

load_figure_data("Figure5_plot_data.RData")
figure5 <- as.data.frame(figure5_cost_data)

stopifnot(
  nrow(figure5) == 324L,
  length(unique(figure5$Country)) == 54L,
  setequal(unique(figure5$exposure), c("heat", "cold", "net")),
  setequal(unique(figure5$metric), c("absolute", "relative"))
)

lookup_figure5 <- function(country, exposure, metric) {
  figure5$map_value[
    figure5$Country == country &
      figure5$exposure == exposure &
      figure5$metric == metric
  ]
}

assert_close(lookup_figure5("India", "heat", "absolute"), 180.2, 0.1, "India heat economic cost")
assert_close(lookup_figure5("India", "net", "absolute"), 182.8, 0.1, "India total economic cost")
assert_close(lookup_figure5("Egypt", "net", "relative"), 18.6, 0.1, "Egypt relative economic cost")
assert_close(lookup_figure5("Nepal", "net", "relative"), 15.3, 0.1, "Nepal relative economic cost")
assert_close(lookup_figure5("Pakistan", "net", "relative"), 14.7, 0.1, "Pakistan relative economic cost")

absolute <- subset(figure5, metric == "absolute")
totals <- tapply(absolute$absolute_estimate / 1e9, absolute$exposure, sum)
assert_close(unname(totals["heat"]), 467.2, 0.1, "Heat-related economic cost")
assert_close(unname(totals["cold"]), 14.2, 0.1, "Cold-related economic cost")
assert_close(unname(totals["net"]), 481.4, 0.1, "Total economic cost")

message("Release validation passed for all public data objects and generated figures.")
