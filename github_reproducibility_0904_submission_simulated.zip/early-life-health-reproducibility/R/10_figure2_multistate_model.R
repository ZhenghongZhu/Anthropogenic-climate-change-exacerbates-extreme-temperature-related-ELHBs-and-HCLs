#!/usr/bin/env Rscript

# Demonstrate or refit the region-specific multistate Cox models underlying
# Figure 2. The public default is a fully synthetic individual-level dataset.

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
require_packages(c("data.table", "mstate", "survival", "splines", "metafor"))
suppressPackageStartupMessages(library(survival))

configured_input <- c(
  getOption("earlylife.figure2_model_input", ""),
  Sys.getenv("FIGURE2_MODEL_INPUT", unset = "")
)
configured_input <- configured_input[nzchar(configured_input)]
simulated_input <- file.path(
  repo_root(), "data", "Figure2_simulated_model_input.RData"
)
input_file <- if (length(configured_input)) configured_input[[1L]] else simulated_input
if (!file.exists(input_file)) {
  stop(
    "Figure 2 model input is absent: ", input_file, ". Generate the public ",
    "synthetic input with 07_generate_figure2_simulated_input.R, or set ",
    "options(earlylife.figure2_model_input = 'path/to/Figure2_model_input.RData')."
  )
}
load(input_file)
input_type <- if (
  normalizePath(input_file, winslash = "/", mustWork = TRUE) ==
    normalizePath(simulated_input, winslash = "/", mustWork = TRUE)
) "simulated" else "authorized"
message("Using ", input_type, " individual-level model input: ", basename(input_file))

requested_regions <- commandArgs(trailingOnly = TRUE)
if (!length(requested_regions)) {
  requested_regions <- getOption("earlylife.regions", character())
}
available_regions <- levels(model_data$region)
region_aliases <- c(
  "Central Asia & Europe" = "Central Asia&Europe",
  "West Asia & North Africa" = "West Asia&North Africa",
  "Latin America" = "Latin American"
)
if (length(requested_regions)) {
  requested_regions <- trimws(requested_regions)
  mapped <- unname(region_aliases[requested_regions])
  requested_regions[!is.na(mapped)] <- mapped[!is.na(mapped)]
}
regions_to_fit <- if (length(requested_regions)) {
  unknown <- setdiff(requested_regions, available_regions)
  if (length(unknown)) stop("Unknown region(s): ", paste(unknown, collapse = ", "))
  requested_regions
} else {
  available_regions
}

transition_matrix <- mstate::transMat(
  list(c(2, 3, 4, 5), c(), c(), c(), c()),
  names = c(
    "Ongoing pregnancy", "Miscarriage", "Stillbirth", "SVN",
    "Term non-SVN live birth"
  )
)
transition_outcomes <- c(
  `1` = "Miscarriage", `2` = "Stillbirth", `3` = "SVN",
  `4` = "Term non-SVN live birth"
)

fit_region <- function(region_name) {
  d <- droplevels(model_data[model_data$region == region_name, ])
  d$event_miscarriage <- as.integer(d$outcome == "miscarriage")
  d$event_stillbirth <- as.integer(d$outcome == "stillbirth")
  d$event_svn <- as.integer(d$outcome == "small vulnerable newborn")
  d$event_term <- as.integer(d$outcome == "term birth")

  msdata <- mstate::msprep(
    data = d,
    trans = transition_matrix,
    time = c(NA, rep("gestational_month", 4L)),
    status = c(
      NA, "event_miscarriage", "event_stillbirth", "event_svn",
      "event_term"
    ),
    keep = c(
      "exposure_class", "relative_humidity", "country", "maternal_age",
      "residence", "maternal_education", "household_wealth", "maternal_bmi",
      "plurality", "infant_sex", "parity", "conception_month", "cluster_id"
    ),
    id = "pregnancy_id"
  )
  msdata$trans <- factor(msdata$trans)

  fit <- survival::coxph(
    survival::Surv(Tstart, Tstop, status) ~
      exposure_class:trans + splines::ns(relative_humidity, 3) + country +
      splines::ns(maternal_age, 3) + splines::ns(conception_month, 4) +
      residence + maternal_education + household_wealth + maternal_bmi +
      plurality + infant_sex + parity + strata(trans),
    id = cluster_id,
    data = msdata
  )

  coefficients <- as.data.frame(summary(fit)$coefficients)
  coefficients$term <- rownames(coefficients)
  coefficients$region <- as.character(region_name)
  rownames(coefficients) <- NULL
  coefficients
}

regional_model_coefficients <- do.call(
  rbind,
  lapply(regions_to_fit, fit_region)
)

extract_exposure <- function(code, label) {
  x <- regional_model_coefficients[
    grepl(paste0("^exposure_class", code, ":trans"), regional_model_coefficients$term),
  ]
  transition <- sub(".*:trans", "", x$term)
  transition <- sub("[^0-9].*$", "", transition)
  x$outcome <- unname(transition_outcomes[transition])
  robust_column <- intersect(c("robust se", "robust.se"), names(x))[[1L]]
  x$HR <- exp(x$coef)
  x$lci <- exp(x$coef - 1.96 * x[[robust_column]])
  x$uci <- exp(x$coef + 1.96 * x[[robust_column]])
  x$exposure <- label
  x[x$outcome %in% c("Miscarriage", "Stillbirth", "SVN"),
    c("exposure", "region", "outcome", "HR", "lci", "uci")]
}

regional_hr <- rbind(
  extract_exposure("1", "Cold <10th percentile"),
  extract_exposure("9", "Heat >90th percentile")
)

pooled_hr <- do.call(rbind, lapply(
  split(regional_hr, interaction(regional_hr$exposure, regional_hr$outcome, drop = TRUE)),
  function(x) {
    se_log <- (log(x$uci) - log(x$lci)) / (2 * 1.96)
    if (nrow(x) == 1L) {
      return(data.frame(
        exposure = x$exposure[[1L]], outcome = x$outcome[[1L]],
        HR = x$HR[[1L]], lci = x$lci[[1L]], uci = x$uci[[1L]],
        I2 = NA_real_, QEp = NA_real_
      ))
    }
    fit <- metafor::rma(yi = log(x$HR), sei = se_log, method = "REML")
    data.frame(
      exposure = x$exposure[[1L]], outcome = x$outcome[[1L]],
      HR = exp(as.numeric(fit$b)), lci = exp(fit$ci.lb), uci = exp(fit$ci.ub),
      I2 = fit$I2, QEp = fit$QEp
    )
  }
))

suffix <- if (length(regions_to_fit) == length(available_regions)) {
  ""
} else {
  paste0("_", gsub("[^A-Za-z0-9]+", "_", paste(regions_to_fit, collapse = "_")))
}
output_dir <- file.path(repo_root(), "outputs", "model")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output_stem <- if (input_type == "simulated") {
  "Figure2_simulated_model_results"
} else {
  "Figure2_refitted_model_results"
}
output_file <- file.path(output_dir, paste0(output_stem, suffix, ".RData"))
model_run_metadata <- list(
  input_type = input_type,
  input_file = basename(input_file),
  records = nrow(model_data),
  regions = as.character(regions_to_fit),
  note = if (input_type == "simulated") {
    "Synthetic demonstration estimates; not manuscript results."
  } else {
    "Refitted estimates from an authorized DHS-derived analytic input."
  }
)
save(
  regional_model_coefficients, regional_hr, pooled_hr, model_run_metadata,
  file = output_file, compress = "xz", version = 3
)
message("Saved Figure 2 model results: ", output_file)
if (input_type == "simulated") {
  message("Synthetic estimates validate code execution only and are not study results.")
}
