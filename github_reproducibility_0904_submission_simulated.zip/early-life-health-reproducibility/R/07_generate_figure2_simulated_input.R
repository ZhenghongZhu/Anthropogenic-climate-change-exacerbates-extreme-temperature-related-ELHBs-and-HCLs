#!/usr/bin/env Rscript

# Generate a fully synthetic individual-level dataset for demonstrating the
# Figure 2 multistate Cox workflow. No DHS records or fitted manuscript values
# are used in this simulation.

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")

set.seed(20260904)

regions <- c(
  "Central Asia&Europe", "East Africa", "Latin American", "South Asia",
  "Southeast Asia", "Southern Africa", "West Africa",
  "West Asia&North Africa"
)
n_per_region <- 6000L
n <- length(regions) * n_per_region
region_index <- rep(seq_along(regions), each = n_per_region)

exposure_levels <- c(as.character(1:9), "99")
exposure_class <- factor(
  sample(exposure_levels, n, replace = TRUE),
  levels = exposure_levels
)
cold <- as.integer(exposure_class == "1")
heat <- as.integer(exposure_class == "9")

maternal_age <- pmin(pmax(round(stats::rnorm(n, 27, 6), 1), 15), 49)
residence <- factor(sample(c("Rural", "Urban"), n, TRUE, c(0.66, 0.34)))
maternal_education <- factor(sample(c("0", "1", "2", "9"), n, TRUE, c(0.24, 0.32, 0.41, 0.03)))
household_wealth <- factor(sample(as.character(1:5), n, TRUE))
maternal_bmi <- factor(sample(c("1", "2", "3", "9"), n, TRUE, c(0.17, 0.56, 0.23, 0.04)))
plurality <- factor(sample(c("1", "2", "9"), n, TRUE, c(0.965, 0.03, 0.005)))
infant_sex <- factor(sample(c("1", "2", "9"), n, TRUE, c(0.49, 0.49, 0.02)))
parity <- factor(sample(c("1", "2", "9"), n, TRUE, c(0.34, 0.64, 0.02)))
conception_month <- sample.int(12L, n, replace = TRUE)

age_risk <- pmax(maternal_age - 35, 0) / 10
twin_risk <- as.integer(plurality == "2")
region_shift <- (region_index - mean(region_index)) / 30

eta_miscarriage <- -1.95 + log(2.1) * cold + log(2.6) * heat +
  0.30 * age_risk + 0.20 * twin_risk + region_shift
eta_stillbirth <- -3.00 + log(1.6) * cold + log(1.7) * heat +
  0.22 * age_risk + 0.25 * twin_risk + region_shift / 2
eta_svn <- -1.15 + log(1.15) * cold + log(1.25) * heat +
  0.18 * age_risk + 0.50 * twin_risk + region_shift / 3

weights <- cbind(
  exp(eta_miscarriage), exp(eta_stillbirth), exp(eta_svn), 1
)
probabilities <- weights / rowSums(weights)
u <- stats::runif(n)
cuts <- t(apply(probabilities, 1L, cumsum))
outcome_index <- 1L + rowSums(u > cuts[, 1:3, drop = FALSE])
outcome_levels <- c(
  "miscarriage", "stillbirth", "small vulnerable newborn", "term birth"
)
outcome <- factor(outcome_levels[outcome_index], levels = outcome_levels)

gestational_month <- integer(n)
gestational_month[outcome == "miscarriage"] <- sample(
  1:6, sum(outcome == "miscarriage"), TRUE,
  prob = c(0.08, 0.14, 0.21, 0.24, 0.20, 0.13)
)
gestational_month[outcome == "stillbirth"] <- sample(
  7:10, sum(outcome == "stillbirth"), TRUE,
  prob = c(0.18, 0.27, 0.34, 0.21)
)
live_birth <- outcome %in% c("small vulnerable newborn", "term birth")
gestational_month[live_birth] <- sample(
  7:10, sum(live_birth), TRUE,
  prob = c(0.05, 0.16, 0.66, 0.13)
)

regional_temperature <- c(15, 24, 23, 27, 27, 22, 29, 20)[region_index]
exposure_offset <- c(
  `1` = -5.0, `2` = -3.6, `3` = -2.5, `4` = -1.5, `5` = -0.6,
  `6` = 0.3, `7` = 1.2, `8` = 2.2, `9` = 4.0, `99` = 0
)

cluster_key <- paste(region_index, sample.int(120L, n, TRUE), sep = "-")
country_index <- sample.int(3L, n, TRUE)

model_data <- data.frame(
  pregnancy_id = seq_len(n),
  cluster_id = as.integer(factor(cluster_key)),
  country = factor(sprintf("SIM_%02d_%d", region_index, country_index)),
  region = factor(regions[region_index], levels = regions),
  survey_weight = stats::runif(n, 0.5, 2.0),
  gestational_month = gestational_month,
  outcome = outcome,
  gestational_temperature = regional_temperature +
    unname(exposure_offset[as.character(exposure_class)]) + stats::rnorm(n, 0, 0.6),
  relative_humidity = pmin(pmax(stats::rnorm(n, 67, 12), 25), 98),
  maternal_age = maternal_age,
  residence = residence,
  maternal_education = maternal_education,
  household_wealth = household_wealth,
  maternal_bmi = maternal_bmi,
  plurality = plurality,
  infant_sex = infant_sex,
  parity = parity,
  conception_month = conception_month,
  exposure_class = exposure_class
)

model_input_dictionary <- data.frame(
  variable = names(model_data),
  description = c(
    "Synthetic pregnancy record identifier",
    "Synthetic cluster identifier",
    "Synthetic country identifier",
    "Eight-region demonstration stratum",
    "Synthetic survey weight",
    "Gestational duration in months",
    "Simulated mutually exclusive pregnancy outcome",
    "Simulated mean gestational temperature in degrees Celsius",
    "Simulated mean gestational relative humidity",
    "Simulated maternal age in years",
    "Simulated urban/rural residence",
    "Simulated maternal education category",
    "Simulated household wealth category",
    "Simulated maternal BMI category",
    "Simulated singleton/plural pregnancy category",
    "Simulated infant sex category",
    "Simulated parity category",
    "Simulated month of conception",
    "Simulated temperature percentile category; 99 is the reference"
  )
)
model_input_counts <- list(
  pregnancies = nrow(model_data),
  by_region = as.data.frame(table(model_data$region, useNA = "ifany")),
  by_outcome = as.data.frame(table(model_data$outcome, useNA = "ifany"))
)
simulation_specification <- list(
  seed = 20260904L,
  records_per_region = n_per_region,
  purpose = paste(
    "Code execution and software validation only; simulated estimates",
    "must not be interpreted as study results."
  )
)

output_file <- file.path(repo_root(), "data", "Figure2_simulated_model_input.RData")
save(
  model_data, model_input_dictionary, model_input_counts,
  simulation_specification,
  file = output_file, compress = "xz", version = 3
)
message("Created synthetic Figure 2 model input: ", output_file)
