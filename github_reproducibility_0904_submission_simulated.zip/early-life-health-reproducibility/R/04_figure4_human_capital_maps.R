#!/usr/bin/env Rscript

source(if (file.exists("R/00_common.R")) "R/00_common.R" else "00_common.R")
source(file.path(repo_root(), "R", "04_map_helpers.R"))
load_figure_data("Figure4_plot_data.RData")

prepared <- prepare_world_geometry(figure4_hcl_data)
d <- prepared$data
world <- prepared$world

specs <- list(
  health = list(
    title = "(a) Health-related HCL attributable to ACC",
    legend = "Cases per 1,000 pregnancies",
    breaks = figure4_scale_spec$health,
    labels = c("0.0", ">0.0 to 4.2", "4.2 to 6.7", "6.7 to 8.3", "8.3 to 21.5", ">=21.5")
  ),
  cognitive = list(
    title = "(b) Cognitive HCL attributable to ACC",
    legend = "IQ points per 1,000 pregnancies",
    breaks = figure4_scale_spec$cognitive,
    labels = c("0.0", ">0.0 to 3.0", "3.0 to 12.0", "12.0 to 20.0", "20.0 to 55.0", ">=55.0")
  ),
  `non-cognitive` = list(
    title = "(c) Non-cognitive HCL attributable to ACC",
    legend = "Cases per 1,000 pregnancies",
    breaks = figure4_scale_spec$`non-cognitive`,
    labels = c("0.0", ">0.0 to 0.005", "0.005 to 0.035", "0.035 to 0.063", "0.063 to 0.168", ">=0.168")
  )
)

make_column <- function(dimension, show_rows = FALSE) {
  s <- specs[[dimension]]
  row_labels <- if (show_rows) c("Heat", "Cold", "Total loss") else rep(NULL, 3)
  maps <- lapply(seq_along(c("heat", "cold", "net")), function(i) {
    make_map_panel(
      d, world, c("heat", "cold", "net")[[i]], "dimension", dimension,
      s$breaks, s$labels,
      title = if (i == 1L) s$title else NULL,
      row_label = if (show_rows) row_labels[[i]] else NULL
    )
  })
  maps[[1L]] / maps[[2L]] / maps[[3L]] / make_bottom_legend(s$legend, s$labels) +
    patchwork::plot_layout(heights = c(1, 1, 1, 0.32))
}

figure4 <- make_column("health", TRUE) |
  make_column("cognitive", FALSE) |
  make_column("non-cognitive", FALSE)
save_png(figure4, "Figure4.png", width = 13.0, height = 7.1, dpi = 300)
